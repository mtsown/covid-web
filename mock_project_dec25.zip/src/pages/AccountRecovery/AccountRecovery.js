import React from 'react';
import { useHistory } from 'react-router-dom';
import { RiVirusLine } from 'react-icons/ri';
import { message, Button } from 'antd';
import './AccountRecovery.css';

function AccountRecovery() {
  const history = useHistory();

  const handleSubmitRecoveryRequest = () => {
    message.success('Request submitted.');
    history.push('/login');
  };

  return (
    <div className="account-recovery">
      <div className="virus-logo">
        <RiVirusLine />
      </div>
      <div>Recover your account</div>
      <div id="recovery-form">
        <form>
          <input type="email" placeholder="name@example.com"></input>
          <hr />
          <select defaultValue='security-question-1'>
            <option value='security-question-1' disabled>Security question 1</option>
            <option>What is your mother's maiden name?</option>
            <option>What is the name of your first pet?</option>
            <option>What was your first car?</option>
          </select>
          <input type="text" placeholder="answer"></input>
          <select defaultValue='security-question-2'>
            <option value='security-question-2' disabled>Security question 2</option>
            <option>What elementary school did you attend?</option>
            <option>What is the name of the town where you were born?</option>
            <option>What was your first car?</option>
          </select>
          <input type="text" placeholder="answer"></input>
          <Button type='primary' size='large' onClick={handleSubmitRecoveryRequest}>SUBMIT</Button>
        </form>
      </div>
    </div>
  );
}

export default AccountRecovery;
