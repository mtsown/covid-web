export { default as notFound } from './not-found.png';
